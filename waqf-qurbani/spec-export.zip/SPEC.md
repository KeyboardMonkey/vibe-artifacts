# Waqf Qurbani Fiqh Brief - Specification

## 1. Overview

A single-page, self-contained Urdu-language fiqh brief that analyses two related questions about Eid al-Adha sacrifice: (a) whether a Waqf Qurbani endowment share can substitute for the wajib annual Qurbani in the Hanafi school, and (b) whether the entire meat of a Qurbani can be donated to charity rather than split into the traditional three shares. The brief is structured as a referenceable, comparative scholarly document with an interactive topic toggle that swaps the comparison tables and core finding between the two questions. The target audience is Hanafi Muslims with intermediate fiqh literacy who need a defensible, citation-backed reference rather than a marketing-oriented charity FAQ.

## 2. Scope

In scope:
- Comparative fiqh analysis across the four Sunni madhabs (Hanafi, Maliki, Shafi'i, Hanbali)
- Five Hanafi conditions for the wajib Qurbani
- Four structural fiqh problems that prevent a waqf share from discharging the wajib
- Quranic and hadith evidence for the meat distribution permission
- Scholarly position breakdown (strict, lenient, procedural, charity self-positioning)
- Practical guidance for Hanafi sahib-e-nisab donors
- Conditions checklists in tabular form for both topics
- Citations from classical Hanafi texts and modern fatawa portals
- Day/night theme toggle with persistence
- Topic toggle (substitution vs meat distribution) with persistence

Out of scope:
- Shia (Ja'fari) jurisprudence
- Aqiqah, Hady, or other related sacrifice categories beyond brief mention
- Charity provider recommendations or rankings
- Calculator or cost estimator functionality
- Multi-language toggle (Urdu only; English appears as monospace metadata labels)
- Server-side persistence, accounts, or sharing

## 3. Functional requirements

- FR-1: The document shall present its entire body content in Urdu using right-to-left direction.
- FR-2: A persistent day/night theme toggle shall appear in the top-right of the header, styled as a pill with DAY and NIGHT labels and a sliding thumb.
- FR-3: Day mode shall be the default theme for first-time visitors. Returning visitors shall see their last-selected theme.
- FR-4: Theme state shall persist in localStorage under the key `wq-theme-ur` with values `light` or `dark`. Storage access shall be wrapped in try/catch so the document degrades gracefully when storage is unavailable.
- FR-5: A topic toggle shall appear directly below the introductory deck, labelled VIEW BY TOPIC, with two pill buttons in Urdu: `وقف قربانی متبادل` (substitution) and `گوشت کی تقسیم` (distribution).
- FR-6: Substitution shall be the default topic for first-time visitors. Returning visitors shall see their last-selected topic.
- FR-7: Topic state shall persist in localStorage under the key `wq-topic-ur` with values `substitution` or `distribution`.
- FR-8: Clicking a topic button shall update three elements without a page reload: (a) the core finding card, (b) the Section 02 Madhabs table, (c) the Section 08 Comparison Matrix table.
- FR-9: The core finding card shall render with a red left-border and red text when topic is substitution (a prohibition statement) and with a green left-border and green text when topic is distribution (a permission statement).
- FR-10: The Section 02 Madhabs table shall present four rows, one per Sunni madhab, with school name in Urdu and Arabic, the school's ruling on Qurbani, the school's view on the active topic's product, and a fiqh note.
- FR-11: The Section 08 Comparison Matrix shall present five rows, each row testing one condition or rule against the two compared models, with a fiqh note column.
- FR-12: Section 01 shall present a static lifecycle illustration as inline SVG comparing regular Qurbani (one-year transaction) and Waqf Qurbani (perpetual endowment).
- FR-13: Section 03 shall present the five Hanafi conditions for a valid wajib Qurbani as a grid of cards.
- FR-14: Section 04 shall present the four structural fiqh problems that prevent waqf qurbani from discharging the wajib, each as a card with a heading, body text, and a classical/modern citation footer.
- FR-15: Section 05 shall present the meat distribution debate with a question card, four evidence cards (two Quranic verses, one hadith, one classical commentary), and a green conclusion box with six supporting bullets.
- FR-16: Section 06 shall present four scholarly position cards (strict majority, lenient minority, charity self-positioning, procedural tawkil grey zone).
- FR-17: Section 07 shall present a five-step practical guidance numbered list in a green-bordered box.
- FR-18: Section 09 shall present six reference blocks covering classical Hanafi texts, hadith sources, modern fatwa portals, the waqf charities' own positions, tawkil-specific fatawa, meat distribution sources, and academic papers on cash waqf.
- FR-19: All section numbers shall use Eastern Arabic-Indic numerals (۰۱ through ۰۹).
- FR-20: All citations of Quranic verses, hadith, and classical works shall include the Arabic phrase in Amiri font alongside the Urdu translation.
- FR-21: The page shall be responsive: at viewport widths ≤ 720px the title shall wrap to multiple lines, the topic and reference grids shall collapse to single column, and the topic toggle pills shall reduce in size.
- FR-22: A footer shall appear at the bottom with the author signature `Syed Ishaq B. · ishaqzafar.com` linking to https://ishaqzafar.com, and a disclaimer that this is a fiqh brief and not a fatwa.

## 4. Non-functional requirements

- NFR-1: The document shall be a single HTML file with no build step, no external JavaScript dependencies, and no server-side requirements.
- NFR-2: First contentful paint shall complete within 2 seconds on a mid-range device with cached fonts.
- NFR-3: All external resources shall be limited to Google Fonts (`fonts.googleapis.com` and `fonts.gstatic.com`).
- NFR-4: The document shall render correctly with JavaScript disabled, except for theme/topic toggle interactivity. In this degraded mode the substitution topic shall be shown.
- NFR-5: Colour contrast in both themes shall meet WCAG AA for body text (4.5:1) and large text (3:1) against the active background.
- NFR-6: The document shall not depend on any third-party tracking, analytics, or CDN beyond Google Fonts.

## 5. Architecture

- Runtime: Single-file static HTML page. No build, no bundler, no transpilation.
- Top-level structure: One `<div class="wrap">` container holding header, title block, topic toggle, key claim card, nine numbered sections, and a footer.
- Components (logical, not framework components):
  - Theme toggle: pill switch with sliding thumb, two labels (DAY, NIGHT), z-index ensures labels paint above thumb, active-side label inverts to background colour.
  - Topic toggle: two pill buttons in a rounded container, active button gets accent background.
  - Key claim card: bordered card with monospace tag, large Nastaliq statement, monospace confidence footer. CSS class `keyclaim.red` or `keyclaim.green` switches colour palette.
  - Section head: row with monospace number, Nastaliq heading, right-aligned monospace hint.
  - Cards: bordered rounded rectangles with optional coloured top accent bar or right-border accent.
  - Tables: full-width, RTL, header row with elevated background, body rows with hover state.
- State management: Two state variables in module scope: current theme (`light` or `dark`), current topic (`substitution` or `distribution`). Both initialised from localStorage with fallback to default. Both written to localStorage on change via try/catch wrappers.
- Data flow: User clicks a topic button → `applyTopic(topicKey)` is called → it reads the corresponding object from the `TOPICS` constant → invokes `renderKeyclaim(t)`, `renderMadhabs(t)`, `renderMatrix(t)` → each renderer rebuilds the relevant section's innerHTML from the topic object → topic key is written to localStorage and active button class is updated.
- External integrations: Google Fonts CDN loads Noto Nastaliq Urdu (400, 500, 600, 700), Amiri (400, 700), and IBM Plex Mono (400, 500). No other network calls.
- Persistence: localStorage keys `wq-theme-ur` and `wq-topic-ur`. No cookies, no IndexedDB, no service worker.

## 6. Data model

The `TOPICS` constant is an object with two keys (`substitution` and `distribution`), each containing a topic specification:

```
TOPICS[<topicKey>] = {
  keyclaimClass: "red" | "green",
  stmt: string (HTML),
  conf: string (HTML),
  madhabsTitle: string,
  madhabsHint: string (HTML),
  madhabsCols: string[] (length 4),
  madhabsRows: MadhabRow[] (length 4),
  matrixTitle: string,
  matrixHint: string (HTML),
  matrixCols: string[] (length 4),
  matrixRows: MatrixRow[] (length 5)
}

MadhabRow = {
  school: string,        // Urdu name, e.g., "حنفی"
  schoolAr: string,      // Arabic name, e.g., "الحنفية"
  col2: string (HTML),   // Ruling on Qurbani, may contain <span class="wajib"> or <span class="sunnah">
  col3Class: "bad" | "ok",
  col3: string,          // Status with ✓ or ✗ prefix
  note: string           // Fiqh detail paragraph
}

MatrixRow = {
  name: string,          // Condition/rule name in Urdu
  sub: string,           // Optional subtitle (empty string if none)
  c1Class: "yes" | "no" | "partial",
  c1: string,            // Cell 1 value with marker prefix
  c2Class: "yes" | "no" | "partial",
  c2: string,            // Cell 2 value with marker prefix
  note: string           // Fiqh detail
}
```

Row ordering for substitution topic Madhabs: Hanafi, Maliki, Shafi'i, Hanbali. Hanafi row must use `col3Class: "bad"` with text `✗ واجب کا متبادل نہیں`. Other three rows use `col3Class: "ok"` with text `✓ نفل و باعثِ اجر`.

Row ordering for distribution topic Madhabs: same four schools in same order. All four rows use `col3Class: "ok"`. Hanafi and Hanbali show `✓ بالکل جائز`. Maliki shows `✓ کوئی پابندی نہیں`. Shafi'i shows `✓ ترجیحی صورت`.

Row ordering for substitution topic Matrix: sahib-e-nisab, niyyah before slaughter, ownership before slaughter, individual obligation, charity self-acknowledgement.

Row ordering for distribution topic Matrix: three equal shares, poor receiving a share, own household consumption, giving nothing to poor (the only prohibition row in this table), 100% via institution.

## 7. UI / UX specification

### Layout
- Outer container: max-width 1280px, margin auto, padding `32px 40px 80px`. Reduces to `24px 20px 60px` at viewport ≤ 720px.
- Direction: `dir="rtl"` on `<html>`. Selective LTR override on technical elements (monospace metadata, English captions, the theme toggle, the SVG illustration).
- Section spacing: section heads have `margin: 80px 0 32px`, bottom border `1px solid var(--border-soft)` with 14px bottom padding.

### Typography
- Body and headings (Urdu): `Noto Nastaliq Urdu`, weights 400, 500, 600, 700. Base line-height 2.2 (Nastaliq requires generous vertical space).
- Arabic religious phrases: `Amiri`, weights 400, 700. Used for Arabic terms like `واجب`, `صدقہ جاریہ`, classical work titles, and Quranic/hadith verses.
- Monospace metadata, English captions, labels, citations: `IBM Plex Mono`, weights 400, 500. Letter-spacing 0.08em to 0.18em depending on context.
- Eyebrow heading: `clamp(32px, 4vw, 48px)`, weight 600, colour `var(--accent)`, line-height 1.4.
- Title h1: `clamp(22px, 2.6vw, 34px)`, weight 600, line-height 1.7, `white-space: nowrap` on desktop (`normal` at ≤ 720px).
- Section h2: 30px, weight 600, line-height 1.6.
- Section number: 14px monospace, weight 600, accent colour, min-width 36px, LTR direction.

### Colour palette

Light mode (default):
```
--bg:         #f8f4ec
--bg-elev:    #f2ecdf
--bg-card:    #fcf9f2
--border:     #d9cfb8
--border-soft:#e8dfca
--fg:         #1a1612
--fg-muted:   #5c4f3e
--fg-dim:     #8a7a64
--accent:     #9c7505   (amber/gold for primary accents and Arabic terms)
--teal:       #2d5f5f   (regular Qurbani panel, sunnah ruling)
--red:        #b91c1c   (prohibition, strict positions, "no" cells)
--green:      #3d6638   (permission, practical guidance, "yes" cells, distribution conclusion)
```

Dark mode:
```
--bg:         #0c0a09
--bg-elev:    #15110e
--bg-card:    #1a1612
--border:     #2a2520
--border-soft:#1f1b17
--fg:         #ebe4d4
--fg-muted:   #a89c87
--fg-dim:     #6b6155
--accent:     #d4a017
--teal:       #6fa8a8
--red:        #ff6b5e
--green:      #7ea878
```

Background gradient: `radial-gradient(circle at 88% 8%, var(--accent-bg) 0%, transparent 50%), radial-gradient(circle at 12% 92%, var(--teal-bg) 0%, transparent 50%)` applied to body.

Theme transitions: `background 0.3s ease, color 0.3s ease` on html and body.

### Component styles

Day/Night toggle:
- Width 132px, height 32px, padding 4px, border-radius 999px, 1px border, monospace 10px labels.
- Sliding thumb: 62px wide, accent background, `transform: translateX()` with cubic-bezier(0.65, 0.05, 0.36, 1) over 320ms.
- Thumb z-index 1, labels z-index 2 so labels paint above thumb.
- Active-side label colour is `var(--bg)` (inverts to background), inactive label is `var(--fg-muted)`.

Topic toggle:
- Container: rounded pill, 1px border, 5px padding, 4px gap.
- Buttons: 16px Nastaliq, 600 weight, 10px-22px padding, transparent background.
- Active button: accent background, `var(--bg)` text, subtle shadow.
- Hover: text colour shifts to `var(--fg)` for inactive buttons.

Key claim card:
- 28px-32px padding, 4px-radius border, right-border 4px solid in topic colour.
- Two variants via class: `.keyclaim` (default red) and `.keyclaim.green`.
- Red variant background `var(--red-bg)`, red border, red statement text.
- Green variant background `var(--green-bg)`, green border, green statement text.
- Tag: monospace 10px, letter-spacing 0.18em, LTR.
- Statement: Nastaliq 22px, weight 500, line-height 2.2.

Lifecycle SVG (Section 01):
- viewBox `0 0 1100 540`, max-width 1100px.
- Two stacked rounded panels (1060 wide, 220 and 240 tall respectively).
- Panel A (regular Qurbani): teal palette, three step boxes plus verdict, "✓ حنفی واجب ادا" in green.
- Panel B (waqf qurbani): amber palette, four step boxes plus verdict, "✗ حنفی واجب نہیں" in red and "✓ صدقہ جاریہ" in green.
- "ملکیت ختم" warning inside the waqf vault step renders in red.
- Inline SVG uses CSS variables for stroke/fill, allowing theme adaptation.

Cards (general):
- 22px-28px padding, 1px border in `var(--border)`, 4px corner radius.
- On hover where applicable: subtle shift in border colour and small translateY for elevation.

Problem cards (Section 04):
- Right-border 4px solid red.
- Heading red, label badge red monospace.
- Body strong tags coloured red.
- Reference footer in elevated background with accent strong tags.

Position cards (Section 06):
- Top 2px accent strip in red (strict), amber (charity self-position), teal (lenient minority), amber (procedural).
- 24px-26px padding, monospace topic tag, Nastaliq heading.

Evidence cards (Section 05):
- 22px-24px padding, 1px border, 4px radius.
- Arabic verse: Amiri 22px, weight 700, line-height 2, RTL, body colour.
- Source: monospace 11px, dim colour.
- Translation: Nastaliq 15px, muted colour, separated from note by dashed border bottom.
- Note: Nastaliq 14px italic, muted colour.

Conclusion green box (Section 05):
- Green-bg background, right-border 4px solid green, 28px-32px padding.
- Statement: Nastaliq 22px, weight 600, green colour.
- List bullets: diamond marker (◆) in green, 24px right-padding, line-height 2.2.
- Inline `.red` spans for the prohibition mention.

Tables (Madhabs and Matrix):
- Full width, border-collapse, 1px border around wrapper, 4px radius.
- Min-width 760px / 820px to trigger horizontal scroll on narrow viewports.
- Header row: monospace 11px-12px uppercase, elevated background.
- Body cells: 18px-22px padding, 1px border bottom, Nastaliq line-height 2.0-2.1.
- Madhabs school cell: Nastaliq 22px weight 700, with Arabic name below in 14px Amiri accent.
- Matrix name cell: Nastaliq 19px weight 700, with optional 14px monospace subtitle.
- Value classes: `.yes` (green, monospace 17px), `.no` (red, monospace 17px), `.partial` (accent, monospace 17px).
- Row hover background: `var(--accent-bg)`.

### Animations and transitions
- Theme switch: 300ms ease on background and colour.
- Thumb slide: 320ms cubic-bezier(0.65, 0.05, 0.36, 1).
- Topic button active: 250ms ease all properties.
- Card hover (where applicable): 220ms ease.

### Empty, loading, and error states
- No loading state: the page is static HTML with synchronous JS initialisation.
- No empty states: data is hard-coded.
- No error states: storage errors are silently caught and ignored.

### Keyboard and accessibility
- Theme toggle has `role="switch"` and `aria-label="Toggle theme"`.
- Topic buttons are native `<button>` elements, focusable and clickable via Enter/Space.
- All interactive elements have visible focus styles via browser defaults; consider explicit `:focus-visible` styles if hardening for accessibility audit.

## 8. Dependencies

External:
- Google Fonts: Noto Nastaliq Urdu (weights 400, 500, 600, 700), Amiri (weights 400, 700), IBM Plex Mono (weights 400, 500), Cormorant Garamond (weights 500, 600 + italics) loaded but lightly used. Single `<link>` to `fonts.googleapis.com/css2`.

Runtime environment:
- Modern browser supporting CSS custom properties, CSS clamp(), flexbox, grid, and ES2015+ JavaScript.
- localStorage available for state persistence (gracefully degrades if not).

No npm packages, no bundler, no transpiler. The file is openable directly in any modern browser.

## 9. Acceptance criteria

- AC-1: Opening the file in a fresh browser loads with day mode active and the substitution topic selected.
- AC-2: Clicking the NIGHT label or thumb on the theme toggle switches the page to dark mode and reloads preserve the choice.
- AC-3: Clicking `گوشت کی تقسیم` switches the core finding card from red to green, updates its statement to the meat distribution finding, and rebuilds the Section 02 Madhabs table and Section 08 Comparison Matrix with the distribution topic data. Reloads preserve the topic choice.
- AC-4: The title `کیا یہ حنفی مذہب میں واجب قربانی کا متبادل بن سکتی ہے؟` renders on a single line on viewports wider than approximately 900px, with no horizontal scrollbar.
- AC-5: All nine sections are numbered ۰۱ through ۰۹ in sequence with no gaps.
- AC-6: The Section 05 conclusion bullets render with green diamond markers and the inline `ممنوع` span renders in red.
- AC-7: The footer signature `Syed Ishaq B. · ishaqzafar.com` is present and links to https://ishaqzafar.com.
- AC-8: At 720px viewport width, the title wraps to multiple lines, the evidence card grid collapses to one column, and the topic toggle reduces button padding.
- AC-9: The HTML source contains the plain-text signature comment near the top and a base64 signature comment inside the script tag.
- AC-10: No em dashes (`—`) appear anywhere in the rendered content or source.

## 10. Constraints and assumptions

- Must be a single-file HTML artifact with no build step or external JS dependencies beyond Google Fonts.
- Must support offline use once fonts are cached by the browser.
- Must respect Hanafi fiqh as the primary madhab framing (the author's school) while presenting the other three Sunni madhabs accurately and without bias.
- Must use Eastern Arabic-Indic numerals (۰-۹) for all section numbers and inline numerics where authenticity matters, while keeping monospace metadata (timestamps, version indicators, citation IDs) in Western Arabic numerals (0-9) for technical legibility.
- Must avoid figurative imagery of animals or people. The lifecycle illustration uses geometric shapes only (rectangles, polygons, circles) with text labels.
- Must avoid em dashes throughout. Use hyphens, commas, or separate sentences.
- Includes an author signature in two forms: a plain-text comment near the top of the document, and a base64-encoded comment containing `U3llZCBJc2hhcSBCLiB8IGlzaGFxemFmYXIuY29t` (which decodes to `Syed Ishaq B. | ishaqzafar.com`) placed deep in the file inside the script tag, prefixed with `sig:` for Ctrl+F discoverability. Neither signature affects execution or rendering.
- All citations are presented as scholarly references for orientation. The document explicitly disclaims being a fatwa and directs readers to consult a trusted scholar for personal rulings.
