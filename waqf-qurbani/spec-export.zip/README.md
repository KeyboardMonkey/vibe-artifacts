# Waqf Qurbani Fiqh Brief

Single-page Urdu fiqh brief on two related Eid al-Adha sacrifice questions, with an interactive topic toggle and day/night theme.

## What this is

A self-contained, single-file HTML document that presents a comparative fiqh analysis of (a) whether a Waqf Qurbani endowment share can substitute for the wajib annual Qurbani in the Hanafi school, and (b) whether the entire Qurbani meat can be donated to charity instead of split into the traditional three shares. Written in Urdu with right-to-left layout, it uses Arabic and Urdu typography (Noto Nastaliq Urdu, Amiri) alongside monospace English metadata for citations and technical markers. The brief draws on classical Hanafi texts (Hidayah, Bada'i al-Sana'i, Fatawa Hindiyya), hadith sources (Sahih Muslim, Sunan Ibn Majah, Jami al-Tirmidhi), and modern fatawa portals.

## Quick start

The artifact is a static HTML file. To view:

```
open src/index.html
```

Or drag `src/index.html` into any modern browser. No build step. No server. No dependencies beyond Google Fonts (loaded from CDN on first open; cached thereafter for offline use).

Interactions:
- Top-right pill toggle: switches between day mode (default) and night mode. State persists in localStorage.
- Below the deck, the VIEW BY TOPIC toggle: switches between the two topics (waqf qurbani substitution vs meat distribution). State persists in localStorage. The core finding, the four-madhabs comparison table, and the conditions matrix all swap content when toggled.

## Architecture at a glance

Single HTML file, no framework. State is held in two JavaScript variables (current theme, current topic) and persisted to localStorage with try/catch wrappers. A single `TOPICS` constant holds the per-topic data (statements, table titles, table columns, table rows). Three render functions (`renderKeyclaim`, `renderMadhabs`, `renderMatrix`) rebuild the relevant DOM sections from the active topic object when the topic toggle is clicked.

See `architecture.svg` for the component layout and data flow.
See `SPEC.md` section 5 for the detailed architecture description and section 6 for the data model.

## File structure

```
export-2026-05-20-waqf-qurbani-fiqh-brief/
  SPEC.md            AI-consumable specification for reproducing the artifact
  README.md          This file
  architecture.svg   Component and data-flow diagram
  .export-meta.json  Export metadata (timestamp, environment, model, artifact type)
  src/
    index.html       The final artifact (single-file HTML, ~1500 lines)
```

## How to modify

For content changes (e.g., adding a citation, updating the conclusion, changing a fiqh note):
- Open `src/index.html`.
- Search for the section number in an HTML comment (e.g., `<!-- SECTION 5: MEAT DISTRIBUTION DEBATE`).
- Edit the relevant HTML block.

For topic-toggleable content (core finding statement, Madhabs table, Comparison Matrix):
- Open `src/index.html`.
- Search for `const TOPICS = {` in the script tag at the end.
- Modify the relevant key under `substitution` or `distribution`.

For visual changes (typography, palette, spacing):
- Search for `:root[data-theme="light"]` or `:root[data-theme="dark"]` for colour variables.
- Section-level styling is grouped by component class name (e.g., `.keyclaim`, `.evidence-card`, `.problem`, `table.madhabs`, `table.matrix`).

To add a third topic (extension point):
- Add a new key under `TOPICS` with the same shape as the existing two.
- Add a new `<button class="tt-btn" data-topic="<new-key>">...</button>` in the `.topic-toggle` div.
- No JS changes required: the existing event wiring and render functions iterate over all `.tt-btn` elements.

To change defaults:
- Default theme: change `getStored('wq-theme-ur') || 'light'` near the top of the script.
- Default topic: change `getStored('wq-topic-ur') || 'substitution'` near the bottom of the script.

## Reproducing from scratch

Feed `SPEC.md` to any capable AI model and ask it to build the product. The spec is self-contained: it does not reference the chat history that produced this artifact. Use `README.md` (this file) for human-oriented context, and `architecture.svg` for a visual overview before reading the spec.

For best results, instruct the model to:
1. Read `SPEC.md` end-to-end before writing code.
2. Match the colour palette and typography specification exactly.
3. Use Eastern Arabic-Indic numerals (۰-۹) for section numbers as specified.
4. Avoid em dashes throughout.

## Notes

- The document is a fiqh brief, not a fatwa. It is intended as a scholarly reference for orientation, not a personal ruling. Personal rulings should come from a trusted scholar familiar with the reader's specific circumstances.
- Hanafi positioning is the primary lens because that is the school the original author follows, but the four-madhabs table presents all four Sunni schools accurately and without bias.
- The artifact deliberately uses geometric shapes only in its lifecycle illustration (no figurative imagery of animals or people).
- Author signature is embedded in two forms inside the source file: a plain-text comment at the top, and a base64-encoded comment deep in the script tag for searchability. Neither affects rendering or behaviour.
- Modern fatawa portals cited (waqf.org, Alkhidmat, Islamic Relief, etc.) are referenced for their public positions on these questions. URLs may rot over time; the canonical references are the classical texts cited in Section 9.
